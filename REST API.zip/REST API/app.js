import express from "express"
import mongoose from "mongoose"
import dotenv from "dotenv"

const app = express()

app.use(express.json())

dotenv.config()

const port = process.env.PORT
const dbUrl = process.env.MONGO_URL

mongoose.connect(dbUrl).then(()=>{
    console.log("MONGODB  connected successfully.")
    app.listen(port, () => {
        console.log(`Server is running on ${port}`)
    })
}).catch((err)=>console.log(err))

const bookSchema = new mongoose.Schema({
    _id:Number,
    title: String,
    author : String,
    quan : Number,
} ,  { versionKey: false })

const mod = mongoose.model("library", bookSchema, "library", { collection: "library" })

app.get('/', (req, res) => {
    res.send('WELCOME TO REST API PROJECT')
})

app.get('/getBooks' , async(req , res)=>{
    try{
        const det = await mod.find()
        res.json(det)
    } catch(err){
        res.send('Library is EMPTY !!')
    }
})

app.get('/getbook/:id', async(req, res) =>{
    try {
        const id = req.params.id
        const book = await mod.findById(id)
        res.send(book)
    } catch (err) {
        res.send('No Book found with given ID !!')
    }
})

app.post('/postbook', async(req, res) => {
    try {
        const book = await mod.create(req.body)
        res.send(book)
        
    } catch (err) {
        res.send('err in Saving the data')
    }
})

app.put('/updatebook/:id', async(req, res) => {
    try {
        const id = req.params.id
        const updatedBook = await mod.findByIdAndUpdate(id, req.body, { new: true })
        const updBook = await mod.findById(id)
        res.send(updBook)
    } catch (err) {
        res.status(404).send(`Can't find book with ID`)
    }
})

app.delete('/deletebook/:id', async(req, res) =>{
    try {
        const id = req.params.id
        const book = await mod.findByIdAndDelete(id)
        res.send(book)
        
    } catch (err) {
        res.status(500).send(`Can't find book with ID ${id}`)
    }
})

/*app.put('/takebook/:id', async(req, res) => {
    try {
        const id = req.params.id
        const book = await mod.findById(id)
        book.quan -= 1
        await book.save()
        res.send(book)
    } catch (err) {
        res.status(500).send('Internal Server err')
    }
})*/
app.put('/takebook/:ids', async (req, res) => {
    try {
        const ids = req.params.ids.split(',')
        const updatedBooks = []
        for (const id of ids) {
            const book = await mod.findById(id)
            if (book.quan > 0) {
                book.quan -= 1
                await book.save()
                updatedBooks.push(book)
            }
        }
        res.send(updatedBooks)
    } catch (err) {
        res.status(500).send('Internal Server Error')
    }
})
